import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {

	const provider = new I4GeradorViewProvider(context.extensionUri);

	context.subscriptions.push(
		vscode.window.registerWebviewViewProvider(I4GeradorViewProvider.viewType, provider));

	context.subscriptions.push(
		vscode.commands.registerCommand('i4Gerador.addColor', () => {
			provider.addColor();
		}));

	context.subscriptions.push(
		vscode.commands.registerCommand('i4Gerador.clearColors', () => {
			provider.clearColors();
		}));

	context.subscriptions.push(
		vscode.commands.registerCommand('i4Gerador.gerarPacote', () => {
			provider.gerarPacote();
		}));
	context.subscriptions.push(
		vscode.commands.registerCommand('i4Gerador.gerarReduzirPacote', () => {
			provider.gerarReduzirPacote();
		}));
	context.subscriptions.push(
		vscode.commands.registerCommand('i4Gerador.reduzirPacote', () => {
			provider.reduzirPacote();
		}));
}

class I4GeradorViewProvider implements vscode.WebviewViewProvider {

	public static readonly viewType = 'i4Gerador.i4GeradorView';

	private _view?: vscode.WebviewView;

	constructor(
		private readonly _extensionUri: vscode.Uri,
	) { }

	public resolveWebviewView(
		webviewView: vscode.WebviewView,
		context: vscode.WebviewViewResolveContext,
		_token: vscode.CancellationToken,
	) {
		this._view = webviewView;

		webviewView.webview.options = {
			// Allow scripts in the webview
			enableScripts: true,

			localResourceRoots: [
				this._extensionUri
			]
		};

		webviewView.webview.html = this._getHtmlForWebview(webviewView.webview);

		webviewView.webview.onDidReceiveMessage(data => {
			switch (data.type) {
				case 'colorSelected':
					{
						vscode.window.activeTextEditor?.insertSnippet(new vscode.SnippetString(`#${data.value}`));
						break;
					}
				case 'novoPacote':{
					const novoPacote = data.value;
					const msg = `Gerando pacote ${novoPacote.nomePacote} da ${novoPacote.retaguarda} para branch ${novoPacote.branch}.`;
					vscode.window.showInformationMessage(` ${msg}`);
					this.showQuickPick();
					break;
				}
				case 'info':
					{
						vscode.window.showInformationMessage(`Info: ${data.value}`);
						break;
					}
				case 'log':
					{
						vscode.window.showWarningMessage(`Log: ${data.value}`);
						break;
					}
				case 'erro':
					{
						vscode.window.showErrorMessage(`Erro: ${data.value}`);
						break;
					}
			}
		});
	}
	public async showQuickPick() {
		let i = 0;
		const result = await vscode.window.showQuickPick(['one', 'two', 'three'], {
			placeHolder: 'one, two or three',
			onDidSelectItem: item =>  vscode.window.showInformationMessage(`Focus ${++i}: ${item}`)
		});
		vscode.window.showInformationMessage(`Got: ${result}`);
	}
	public addColor() {
		if (this._view) {
			this._view.show?.(true); // `show` is not implemented in 1.49 but is for 1.50 insiders
			this._view.webview.postMessage({ type: 'addColor' });
		}
	}

	public clearColors() {
		if (this._view) {
			this._view.webview.postMessage({ type: 'clearColors' });
		}
	}

	public gerarPacote() {
		if (this._view) {
			this._view.webview.postMessage({ type: 'gerarPacote' });
		}
	}

	public gerarReduzirPacote() {
		if (this._view) {
			this._view.webview.postMessage({ type: 'gerarReduzirPacote' });
		}
	}

	public reduzirPacote() {
		if (this._view) {
			this._view.webview.postMessage({ type: 'reduzirPacote' });
		}
	}


	private _getHtmlForWebview(webview: vscode.Webview) {
		// Get the local path to main script run in the webview, then convert it to a uri we can use in the webview.
		const scriptUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'media', 'main.js'));

		// Do the same for the stylesheet.
		const styleResetUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'media', 'reset.css'));
		const styleVSCodeUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'media', 'vscode.css'));
		const styleMainUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'media', 'main.css'));

		// Use a nonce to only allow a specific script to be run.
		const nonce = getNonce();

		return `<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">

	<!--
					Use a content security policy to only allow loading styles from our extension directory,
					and only allow scripts that have a specific nonce.
					(See the 'webview-sample' extension sample for img-src content security policy examples)
				-->
	<meta http-equiv="Content-Security-Policy"
		content="default-src 'none'; style-src ${webview.cspSource}; script-src 'nonce-${nonce}';">

	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link href="${styleResetUri}" rel="stylesheet">
	<link href="${styleVSCodeUri}" rel="stylesheet">
	<link href="${styleMainUri}" rel="stylesheet">

	<title>Cat Colors</title>
</head>

<body>


	<!--
	<ul class="color-list">
	</ul>
	
	<button class="add-color-button">Add Color</button>
	-->


	<h2>Gerador de Pacotes Integrado</h2>
	<h6>Autor: Cesar Augusto Oliveira</h6>
	<p id='p1'>Ferramenta de integração de API para Gerador de Pacotes com Visual Studio Code e Azure Data Studio, junto a funcionalidade de redutor de pacotes.</p>


	
	<!-- multistep form -->
	<!-- fieldsets -->
	<fieldset>
	<h2 class="fs-title">Credenciais</h2>
	<h4 class="fs-subtitle">Forneça os dados base para a integração.</h3>
	<div class="invalid-cred" >
	<label class="invalid-cred-label" hidden>Credenciais Invalidas!</label>
	</div>
		<input type="text" id="userLogin" placeholder="Login" />
		<input type="password" id="userPassword" placeholder="Senha" />
		<input type="text" id="pathLocalRepo" placeholder="C:/Caminho/Repositorio/Local/" />
		<h6><i>O diretorio do repositorio local GIT <b>DEVE</b> estar preenchido e correto para utilizar algumas funcionalidades do redutos de pacotes.</i></h6>
	</fieldset>
	<fieldset>
		<h2 class="fs-title">Gerar Pacote</h2>
		<h4 class="fs-subtitle">Informações do pacote.</h3>

		<br>

		<label for="retaguarda-select">Retaguarda: </label>
		<select id="retaguarda-select" disabled class="retaguarda-select selectcss" disabled>
			<option value=""  >--Please choose an option--</option>
		</select>

		
		<label for="branch-select">Branch: </label>
		<select id="branch-select" class="branch-select selectcss" disabled>
			<option value="" >--Please choose an option--</option>
		</select>

	<!--
		<input type="text" name="branch" placeholder="Branch" />
-->
		<label for="nome-pacote-select">Nome do Pacote: </label>
		<select id="nome-pacote-select" class="nome-pacote-select selectcss" disabled>
			<option value=""  >--Please choose an option--</option>
		</select>

	
		<label for="modo-select">Modo: </label>
		<select id="modo-select" class="modo-select selectcss" disabled>
		<option value="Branch" selected>Branch</option>
		<option value="Head">Head</option>
		</select>
		<br>
		
		<button id="gerar" class="gerar"  disabled>Gerar</button>
		<button id="gerarCompatar" class="gerar"  disabled>Gerar e Compactar</button>
		<br>

	</fieldset>
	<fieldset>
		<h2 class="fs-title">Redudor de Pacote</h2>
		<h4 class="fs-subtitle">Informações do pacote.</h3>
		<div class="invalid-cred" >
			<label class="lblPathPacote" hidden>Credenciais Invalidas!</label>
		</div>

		<br>
		
		<label for="">Diretorio do Pacote Gerado: </label>
		<input type="text" id="pathPacoteGerado" placeholder="E:/Pacotes/" />

		<label for="">Arquivos Customizados: </label>
		<input type="text" id="listArquivosParaManter" placeholder="C:/i4/ArquivosParaManter.txt" />
		<h6></i>Deixe vazio para usar o historico do GIT. <br> LEMBRE! Você deve confirmar que são os arquivos corretos!!</i></h6>

		<br>
		<label for="">Diretorio de Destino: </label>
		<input type="text" id="pathDestinoPacote" placeholder="C:/i4/PacotesReduzidos/" />
		<h6><i>Deixe vazio para usar o padrão: </i>"C:/i4/PacotesReduzidos/".</h6>

		<br>
		
		<button id="redux" class="gerar"  disabled>Compactar</button>
		<br>
	</fieldset>

</body>
<script nonce="${nonce}" src="${scriptUri}"></script>

</html>`;
	}
}

function getNonce() {
	let text = '';
	const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	for (let i = 0; i < 32; i++) {
		text += possible.charAt(Math.floor(Math.random() * possible.length));
	}
	return text;
}
