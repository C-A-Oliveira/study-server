"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.activate = activate;
const vscode = require("vscode");
function activate(context) {
    const provider = new I4GeradorViewProvider(context.extensionUri);
    context.subscriptions.push(vscode.window.registerWebviewViewProvider(I4GeradorViewProvider.viewType, provider));
    context.subscriptions.push(vscode.commands.registerCommand('i4Gerador.addColor', () => {
        provider.addColor();
    }));
    context.subscriptions.push(vscode.commands.registerCommand('i4Gerador.clearColors', () => {
        provider.clearColors();
    }));
}
class I4GeradorViewProvider {
    constructor(_extensionUri) {
        this._extensionUri = _extensionUri;
    }
    resolveWebviewView(webviewView, context, _token) {
        this._view = webviewView;
        webviewView.webview.options = {
            // Allow scripts in the webview
            enableScripts: true,
            localResourceRoots: [
                this._extensionUri
            ]
        };
        webviewView.webview.html = this._getHtmlForWebview(webviewView.webview);
        webviewView.webview.onDidReceiveMessage(data => {
            switch (data.type) {
                case 'colorSelected':
                    {
                        vscode.window.activeTextEditor?.insertSnippet(new vscode.SnippetString(`#${data.value}`));
                        break;
                    }
            }
        });
    }
    addColor() {
        if (this._view) {
            this._view.show?.(true); // `show` is not implemented in 1.49 but is for 1.50 insiders
            this._view.webview.postMessage({ type: 'addColor' });
        }
    }
    clearColors() {
        if (this._view) {
            this._view.webview.postMessage({ type: 'clearColors' });
        }
    }
    _getHtmlForWebview(webview) {
        // Get the local path to main script run in the webview, then convert it to a uri we can use in the webview.
        const scriptUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'media', 'main.js'));
        // Do the same for the stylesheet.
        const styleResetUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'media', 'reset.css'));
        const styleVSCodeUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'media', 'vscode.css'));
        const styleMainUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'media', 'main.css'));
        // Use a nonce to only allow a specific script to be run.
        const nonce = getNonce();
        return `<!DOCTYPE html>
			<html lang="en">
			<head>
				<meta charset="UTF-8">

				<!--
					Use a content security policy to only allow loading styles from our extension directory,
					and only allow scripts that have a specific nonce.
					(See the 'webview-sample' extension sample for img-src content security policy examples)
				-->
				<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${webview.cspSource}; script-src 'nonce-${nonce}';">

				<meta name="viewport" content="width=device-width, initial-scale=1.0">

				<link href="${styleResetUri}" rel="stylesheet">
				<link href="${styleVSCodeUri}" rel="stylesheet">
				<link href="${styleMainUri}" rel="stylesheet">

				<title>Cat Colors</title>
			</head>
			<body>
	        <select id="branch-select" class="branch-select">
            
                </select>
                
				<ul class="color-list">
				</ul>

				<button class="add-color-button">Add Color</button>

				<script nonce="${nonce}" src="${scriptUri}"></script>

				<h1>Titulo aqui</h1>
                <h6>Autor: Cesar Augusto Oliveira</h6>
                <p id='p1'>Ferramenta de integração blah blah com Visual Studio Code.</p>

                <label for="pet-select">Choose a pet:</label>

                <select name="pets" id="pet-select">
                <option value="">--Please choose an option--</option>
                <option value="dog">Dog</option>
                <option value="cat">Cat</option>
                <option value="hamster">Hamster</option>
                <option value="parrot">Parrot</option>
                <option value="spider">Spider</option>
                <option value="goldfish">Goldfish</option>
                </select>



		<!-- multistep form -->
		<form id="msform">
			<!-- fieldsets -->
			<fieldset>
				<h2 class="fs-title">Credenciais</h2>
				<h3 class="fs-subtitle">Forneça os dados base para a integração.</h3>
				<input type="text" name="login" placeholder="Login" onChange="vscode.postMessage({command:'login'})" onClick="vscode.postMessage({command:'login'})"/>
				<input type="password" name="pass" placeholder="Senha" />
				<input type="text" name="pathLocalRepo" placeholder="C:/Caminho/Repositorio/Local" />
			</fieldset>
			<fieldset>
				<h2 class="fs-title">Gerar Pacote</h2>
				<h3 class="fs-subtitle">Informações do pacote.</h3>
				<input list="Retaguarda" name="Retaguarda" placeholder="Retaguarda">
				<datalist id="Retaguarda" > 
					<option value="Edge">
					<option value="Firefox">
					<option value="Chrome">
					<option value="Opera">
					<option value="Safari">
				</datalist>
							
				<input type="text" name="branch" placeholder="Branch" />
	
				<input list="nomePacote" name="nomePacote" placeholder="Nome do pacote">
				<datalist id="nomePacote" > 
					<option value="Edge">
					<option value="Firefox">
					<option value="Chrome">
					<option value="Opera">
					<option value="Safari">
				</datalist>
	
				<input list="modo" name="modo" placeholder="Modo">
				<datalist id="modo" > 
					<option value="Branch" >
					<option value="Head">
				</datalist>
					<button id="gerar" class="gerar">Gerar</button>
			</fieldset>
		</form>
			</body>
			</html>`;
    }
}
I4GeradorViewProvider.viewType = 'i4Gerador.i4GeradorView';
function getNonce() {
    let text = '';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < 32; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
}
//# sourceMappingURL=extension.js.map