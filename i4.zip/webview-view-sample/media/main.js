
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-nocheck

// This script will be run within the webview itself
// It cannot access the main VS Code APIs directly.
//import { get } from "axios"
//import { parse } from "fast-xml-parser"
//import { globalAgent } from "https"

// import * as https from 'https';
// import * as axiosntlm from 'axios-ntlm';
// import * as xmldom from 'xmldom';
// import { exec } from 'node:child_process';




let isUserValidOrConnected = false;
let userLogin = '';
let userPassword = '';
let pathLocalRepo = '';
let retaguarda = '';
let retaguardas = ['Um', 'Dois', 'Tres'];
let branchRetaguarda = '';
let branchsRetaguardas = [];
let nomePacoteRetaguarda = '';
let nomePacoteRetaguardas = [];
let modo = '';

let
    novoPacote = {
        retaguarda: "",
        nomePacote: "",
        branch: ""
    };

const pathDestinoPacote = 'C:/i4/';
const pathPacote = '' + '.zip';
let credentials = {
    username: 'ceoliveira',
    password: "I$pro07",
    domain: ''
};


(function () {
    const vscode = acquireVsCodeApi();
    updateCredentials();
    modo = document.getElementById('modo-select').value;

    //Reset dos valores dos dropdowns, mantem o primeiro    
    function resetDropdown(dropdown) {
        let dropdownValues = dropdown.getElementsByTagName('option');
        for (let index = dropdownValues.length - 1; index > 0; index--) {
            dropdown.removeChild(dropdownValues[index]);
        }
    }
    function refreshDropdown(dropdown) {
        let dropdownValues = dropdown.getElementsByTagName('option');
        for (let index = dropdownValues.length - 1; index > 0; index--) {
            dropdown.removeChild(dropdownValues[index]);
        }
    }
    function validadePath() {

    }
    // async function getURL(client, URL) {
    //     try {
    //         let resp = await client({
    //             url: URL,
    //             method: 'get'
    //         });
    //         return resp;
    //     }
    //     catch (err) {
    //         console.log(err);
    //         console.log("Failed");
    //     }
    // }
    // function validateCredentials() {

    //     try {

    //         // const client = axiosntlm.NtlmClient(credentials);
    //         // const I4propacote = await getURL(client, "http://jarvis/I4propacote");
    //         // if (I4propacote.status == 200) {
    //         //     isUserValidOrConnected = true;

    //         //     const dom = new xmldom.DOMParser().parseFromString(I4propacote.data, 'text/html');
    //         //     //console.log(dom.childNodes[2].childNodes[3].childNodes[5].childNodes[3].childNodes[3])
    //         //     const listaRetaguardas = dom.childNodes[2].childNodes[3].childNodes[5].childNodes[3].childNodes[3];
    //         //     console.log(listaRetaguardas.childNodes.length);
    //         //     for (var i = 1; i < listaRetaguardas.childNodes.length; i += 2) {
    //         //         const element = listaRetaguardas.childNodes[i];
    //         //         retaguardas.push({ 'url': element.attributes[0].value, 'area': element.attributes[0].value.split("/").pop() });

    //         //     }
    //         // }
    //         // else {
    //         //     isUserValidOrConnected = false;

    //         // }
    //         return isUserValidOrConnected;
    //         // console.log(dom)
    //     }
    //     catch (err) {
    //         console.log(err);
    //         console.log("Failed");
    //     }
    // }

    function validateCredentials() {
        if (credentials.username == 'a' && credentials.password == 'a')
            isUserValidOrConnected = true;
        else isUserValidOrConnected = false;
        return isUserValidOrConnected;
    }
    function updateCredentials() {
        if (userLogin !== "" && userPassword !== "" && userLogin !== null && userPassword !== null) {
            //vscode.postMessage({ type: 'colorSelected', value: 'bruh' });

            credentials.username = userLogin;
            credentials.password = userPassword;
            if (!validateCredentials()) {
                retaguarda = '';
                retaguardas = [];
                branchsRetaguarda = '';
                branchsRetaguardas = [];
                nomePacoteRetaguarda = '';
                nomePacoteRetaguardas = [];
                modo = '';

                refreshDropdown(document.getElementById('retaguarda-select'));
                refreshDropdown(document.getElementById('nome-pacote-select'));
                refreshDropdown(document.getElementById('branch-select'));
                document.getElementById('retaguarda-select').disabled = true;
                document.getElementById('branch-select').disabled = true;
                document.getElementById('nome-pacote-select').disabled = true;
                document.getElementById('modo-select').disabled = true;
                document.getElementById('gerar').setAttribute("disabled", "");
                document.querySelector('.invalid-cred-label').removeAttribute("hidden");
                vscode.postMessage({ type: 'log', value: 'Reset' });
                vscode.postMessage({ type: 'log', value: 'Crenciais Invalidas!' });
            }
            else {
                document.getElementById('gerar').removeAttribute("disabled");
                document.getElementById('branch-select').disabled = false;
                document.querySelector('.invalid-cred-label').setAttribute("hidden", "");
                loadRetaguarda();
                loadBranch();
                vscode.postMessage({ type: 'colorSelected', value: 'Valido' });
            }
        }
    }
    // userLogin
    document.getElementById('userLogin').addEventListener('change', function () {
        const htmlSelect = document.getElementById('userLogin');
        userLogin = htmlSelect.value;
        updateCredentials();
    });
    // userPassword
    document.getElementById('userPassword').addEventListener('change', function () {
        const htmlSelect = document.getElementById('userPassword');
        userPassword = htmlSelect.value;
        updateCredentials();
    });
    // pathLocalRepo
    document.getElementById('pathLocalRepo').addEventListener('change', function () {
        const htmlSelect = document.getElementById('pathLocalRepo');
        pathLocalRepo = htmlSelect.value;
    });


    //#region  RETAGUARDA
    // Pegar valor ao mudar o selecionado de uma lista
    document.getElementById('retaguarda-select').addEventListener('change', function () {
        setRetaguarda();
    });
    // Carrega valores á uma lista
    function loadRetaguarda() {
        retaguardas = ['Um', 'Dois', 'Tres']; // A Consulta REST dos nomes dos pacotes vem aqui -- ADAPTAR

        const htmlSelect = document.getElementById('retaguarda-select');
        htmlSelect.disabled = false;
        refreshDropdown(htmlSelect);
        for (const item of retaguardas) {
            htmlSelect.options[htmlSelect.options.length] = new Option(item, item);
        }
    }
    function setRetaguarda() {
        const htmlSelect = document.getElementById('retaguarda-select');
        retaguarda = htmlSelect.value;
        loadNomePacotes();
    }
    //#endregion



    //#region NOME DO PACOTE
    //
    document.getElementById('nome-pacote-select').addEventListener('change', function () {
        setNomePacote();
    });
    function loadNomePacotes() {
        switch (retaguarda) { // A Consulta REST dos nomes dos pacotes vem aqui -- ADAPTAR
            case 'Um':
                nomePacoteRetaguardas = ['Um - Pa', 'Um - to', 'Um - lino'];
                break;
            case 'Dois':
                nomePacoteRetaguardas = ['Dois - Pa', 'Dois - te', 'Dois - ta'];
                break;
            case 'Tres':
                nomePacoteRetaguardas = ['Tres - Pa', 'Tres - ris'];
                break;
            default:
                break;
        }
        vscode.postMessage({ type: 'colorSelected', value: retaguarda + 'asa' });

        const htmlSelect = document.getElementById('nome-pacote-select');
        htmlSelect.disabled = false;
        refreshDropdown(htmlSelect);
        for (const item of nomePacoteRetaguardas) {
            htmlSelect.options[htmlSelect.options.length] = new Option(item, item);
        }
    }

    function setNomePacote() {
        const htmlSelect = document.getElementById('nome-pacote-select');
        nomePacoteRetaguarda = htmlSelect.value;

        vscode.postMessage({ type: 'colorSelected', value: nomePacoteRetaguarda });

        document.getElementById('modo-select').disabled = false;
    }
    //#endregion



    //#region MODO
    document.getElementById('modo-select').addEventListener('change', function () {
        modo = document.getElementById('modo-select').value;
        vscode.postMessage({ type: 'colorSelected', value: modo });
    });
    //#endregion



    //#region GERAR
    document.getElementById('gerar').addEventListener('click', () => {
        gerar();
    });

    function gerar() {
        novoPacote.retaguarda = retaguarda;
        novoPacote.nomePacote = nomePacoteRetaguarda;
        novoPacote.branch = branchRetaguarda;

        vscode.postMessage({ type: 'novoPacote', value: novoPacote }).;
        const msg = `Gerando pacote ${novoPacote.nomePacote} da ${novoPacote.retaguarda} para branch ${novoPacote.branch}.`;
 
    }
    //#endregion

    //#region Resto
    loadBranch();
    function loadBranch() {
        const htmlSelect = document.getElementById("branch-select");
        let branches = ['a', 'b', 'd'];
        //vscode.postMessage({ type: 'colorSelected', value: htmlSelect.value });
        //vscode.postMessage({ type: 'colorSelected', value: htmlSelect.options.length });

        for (const branch of branches) {
            htmlSelect.options[htmlSelect.options.length] = new Option(branch, branch);
        }
    }
    document.getElementById('branch-select').addEventListener('change', function () {
        const htmlSelect = document.getElementById('branch-select');
        branchRetaguarda = htmlSelect.value;
        //vscode.postMessage({ type: 'colorSelected', value: htmlSelect.value });

    });
    const oldState = vscode.getState() || { colors: [] };

    /** @type {Array<{ value: string }>} */
    let colors = oldState.colors;

    updateColorList(colors);
    document.querySelector('.add-color-button').addEventListener('click', () => {


        addColor();
    });

    // document.querySelector('.add-color-button').addEventListener('click', () => {
    //     const htmlSelect = document.getElementById('branch-select');
    //     //htmlSelect.textContent = '';
    //     let branches = ['a','b','d'];
    //     for (const branch of branches){
    //         // const htmlOption = document.createElement('option');
    //         // htmlOption.className = 'branch-entry';
    //         // htmlOption.value = branch.value;
    //         // htmlOption.textContent = branch.value;

    //         // htmlSelect.appendChild(htmlOption);
    //         htmlSelect.options[htmlSelect.options.length] = new Option(branch,branch);
    //     }
    // });

    // Handle messages sent from the extension to the webview
    window.addEventListener('message', event => {
        const message = event.data; // The json data that the extension sent
        switch (message.type) {
            case 'addColor':
                {
                    addColor();
                    break;
                }
            case 'clearColors':
                {
                    colors = [];
                    updateColorList(colors);
                    break;
                }


        }
    });

    /**
     * @param {Array<{ value: string }>} colors
     */
    function updateColorList(colors) {
        const ul = document.querySelector('.color-list');
        ul.textContent = '';
        for (const color of colors) {
            const li = document.createElement('li');
            li.className = 'color-entry';

            const colorPreview = document.createElement('div');
            colorPreview.className = 'color-preview';
            colorPreview.style.backgroundColor = `#${color.value}`;
            colorPreview.addEventListener('click', () => {
                onColorClicked(color.value);
            });
            li.appendChild(colorPreview);

            const input = document.createElement('input');
            input.className = 'color-input';
            input.type = 'text';
            input.value = color.value;
            input.addEventListener('change', (e) => {
                const value = e.target.value;
                if (!value) {
                    // Treat empty value as delete
                    colors.splice(colors.indexOf(color), 1);
                } else {
                    color.value = value;
                }
                updateColorList(colors);
            });
            li.appendChild(input);

            ul.appendChild(li);



        }

        // Update the saved state
        vscode.setState({ colors: colors });

        // const htmlSelect = document.getElementById('branch-select');
        // //htmlSelect.textContent = '';
        // let branches = ['a','b','d'];
        // for (const branch of branches){
        //     // const htmlOption = document.createElement('option');
        //     // htmlOption.className = 'branch-entry';
        //     // htmlOption.value = branch.value;
        //     // htmlOption.textContent = branch.value;

        //     // htmlSelect.appendChild(htmlOption);
        //     htmlSelect.options[htmlSelect.options.length] = new Option(branch,branch);
        // }

    }

    /** 
     * @param {string} color 
     */
    function onColorClicked(color) {
        vscode.postMessage({ type: 'colorSelected', value: color });
    }

    /**
     * @returns string
     */
    function getNewCalicoColor() {
        const colors = ['020202', 'f1eeee', 'a85b20', 'daab70', 'efcb99'];
        return colors[Math.floor(Math.random() * colors.length)];
    }

    function addColor() {
        colors.push({ value: getNewCalicoColor() });
        updateColorList(colors);
    }
    //#endregion
}());


